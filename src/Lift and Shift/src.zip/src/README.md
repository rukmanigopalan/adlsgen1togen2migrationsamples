# adlsgen1togen2migrationsamples
This folder contains the working code samples and step by step guide documentation for:
  * **Incremental Copy Pattern**
  
  * **Bi-directional sync Pattern**
  
Access here [Incremental copy pattern guide](https://github.com/rukmani-msft/adlsgen1togen2migrationsamples/blob/master/src/Incremental/README.md)
  
Access here [Bi-directional sync pattern guide](https://github.com/rukmani-msft/adlsgen1togen2migrationsamples/blob/master/src/Bi-directional/README.md)

